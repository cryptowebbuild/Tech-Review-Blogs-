import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Search, ArrowRight, TrendingUp, Package, GraduationCap, Palette, Code, Camera, Music, Video, Filter } from 'lucide-react'

const categories = [
  {
    id: 1,
    name: "AI Tools",
    description: "Artificial intelligence software and tools for productivity, creativity, and automation",
    icon: TrendingUp,
    postCount: 45,
    color: "bg-blue-500",
    trending: true,
    latestPost: "ChatGPT Plus vs Claude Pro: Which AI Assistant is Better?",
    totalViews: 125000,
    avgRating: 4.6
  },
  {
    id: 2,
    name: "Digital Products",
    description: "Downloadable products, templates, and digital resources for creators and professionals",
    icon: Package,
    postCount: 32,
    color: "bg-green-500",
    trending: false,
    latestPost: "Best Digital Planners for 2024: Complete Review",
    totalViews: 89000,
    avgRating: 4.4
  },
  {
    id: 3,
    name: "Online Courses",
    description: "E-learning platforms, online courses, and educational resources for skill development",
    icon: GraduationCap,
    postCount: 28,
    color: "bg-purple-500",
    trending: true,
    latestPost: "Coursera Plus Review: Is It Worth the Subscription?",
    totalViews: 156000,
    avgRating: 4.7
  },
  {
    id: 4,
    name: "Design Software",
    description: "Creative and design tools for graphic design, UI/UX, and digital art",
    icon: Palette,
    postCount: 36,
    color: "bg-pink-500",
    trending: false,
    latestPost: "Figma vs Sketch: The Ultimate Design Tool Comparison",
    totalViews: 98000,
    avgRating: 4.5
  },
  {
    id: 5,
    name: "Development Tools",
    description: "Programming, development software, and tools for developers and coders",
    icon: Code,
    postCount: 41,
    color: "bg-orange-500",
    trending: true,
    latestPost: "GitHub Copilot vs Tabnine: AI Code Assistant Battle",
    totalViews: 112000,
    avgRating: 4.8
  },
  {
    id: 6,
    name: "Photography",
    description: "Photo editing software, management tools, and photography resources",
    icon: Camera,
    postCount: 24,
    color: "bg-cyan-500",
    trending: false,
    latestPost: "Lightroom vs Capture One: Professional Photo Editing",
    totalViews: 76000,
    avgRating: 4.3
  },
  {
    id: 7,
    name: "Audio & Music",
    description: "Music production software, audio editing tools, and sound engineering resources",
    icon: Music,
    postCount: 19,
    color: "bg-red-500",
    trending: false,
    latestPost: "Logic Pro X vs Ableton Live: Music Production Showdown",
    totalViews: 54000,
    avgRating: 4.6
  },
  {
    id: 8,
    name: "Video Editing",
    description: "Video production, editing software, and content creation tools",
    icon: Video,
    postCount: 27,
    color: "bg-indigo-500",
    trending: true,
    latestPost: "DaVinci Resolve vs Premiere Pro: Professional Video Editing",
    totalViews: 189000,
    avgRating: 4.7
  }
]

export default function CategoriesPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container px-4 md:px-6 py-8">
        {/* Header Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl mb-4">
            Browse Categories
          </h1>
          <p className="text-xl text-muted-foreground max-w-[700px] mx-auto mb-8">
            Explore our comprehensive reviews organized by category. Find exactly what you're looking for with our expert analysis.
          </p>
          
          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-4 max-w-2xl mx-auto mb-8">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search categories..."
                className="pl-10"
              />
            </div>
            <Select>
              <SelectTrigger className="w-full sm:w-[180px]">
                <Filter className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popular">Most Popular</SelectItem>
                <SelectItem value="trending">Trending</SelectItem>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-2xl font-bold text-primary">8</div>
              <div className="text-sm text-muted-foreground">Categories</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-2xl font-bold text-primary">252</div>
              <div className="text-sm text-muted-foreground">Total Reviews</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-2xl font-bold text-primary">1.2M</div>
              <div className="text-sm text-muted-foreground">Total Views</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-2xl font-bold text-primary">4.6</div>
              <div className="text-sm text-muted-foreground">Avg Rating</div>
            </CardContent>
          </Card>
        </div>

        {/* Categories Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {categories.map((category) => {
            const IconComponent = category.icon
            return (
              <Card key={category.id} className="group hover:shadow-lg transition-all duration-300 cursor-pointer">
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-lg ${category.color} bg-opacity-10`}>
                      <IconComponent className={`h-6 w-6 ${category.color.replace('bg-', 'text-')}`} />
                    </div>
                    <div className="flex items-center gap-2">
                      {category.trending && (
                        <Badge variant="secondary" className="text-xs">
                          Trending
                        </Badge>
                      )}
                      <Badge variant="outline" className="text-xs">
                        {category.postCount} reviews
                      </Badge>
                    </div>
                  </div>
                  
                  <CardTitle className="text-xl mb-2 group-hover:text-primary transition-colors">
                    {category.name}
                  </CardTitle>
                  
                  <p className="text-muted-foreground text-sm line-clamp-2 mb-4">
                    {category.description}
                  </p>
                </CardHeader>
                
                <CardContent className="pt-0">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Latest Review:</span>
                      <span className="font-medium text-xs text-right max-w-[150px] line-clamp-2">
                        {category.latestPost}
                      </span>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Total Views:</span>
                      <span className="font-medium">{category.totalViews.toLocaleString()}</span>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Avg Rating:</span>
                      <div className="flex items-center gap-1">
                        <span className="font-medium">{category.avgRating}</span>
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <div
                              key={i}
                              className={`w-3 h-3 rounded-full ${
                                i < Math.floor(category.avgRating)
                                  ? 'bg-yellow-400'
                                  : 'bg-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    <Button className="w-full mt-4">
                      Browse Category
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </div>
  )
}