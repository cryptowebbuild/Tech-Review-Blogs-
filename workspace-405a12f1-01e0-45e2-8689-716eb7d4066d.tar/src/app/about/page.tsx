import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { Mail, Phone, MapPin, Star, Users, BookOpen, Award, Target, Heart, CheckCircle, ArrowRight, Facebook, Twitter, Instagram, Youtube, Linkedin } from 'lucide-react'

const teamMembers = [
  {
    name: "Sarah Johnson",
    role: "Founder & CEO",
    avatar: "SJ",
    bio: "Tech enthusiast with 10+ years of experience in digital marketing and product reviews. Passionate about helping consumers make informed decisions.",
    expertise: ["Product Strategy", "Content Creation", "Affiliate Marketing"],
    social: {
      twitter: "#",
      linkedin: "#",
      email: "sarah@techreviewpro.com"
    }
  },
  {
    name: "Mike Chen",
    role: "Lead Reviewer",
    avatar: "MC",
    bio: "Design expert and software reviewer with a keen eye for detail. Specializes in design tools and creative software.",
    expertise: ["Design Software", "UI/UX", "Creative Tools"],
    social: {
      twitter: "#",
      linkedin: "#",
      email: "mike@techreviewpro.com"
    }
  },
  {
    name: "Emily Davis",
    role: "Content Manager",
    avatar: "ED",
    bio: "Content strategist and writer with a passion for making complex technology accessible to everyone.",
    expertise: ["Content Strategy", "Technical Writing", "SEO"],
    social: {
      twitter: "#",
      linkedin: "#",
      email: "emily@techreviewpro.com"
    }
  },
  {
    name: "David Kim",
    role: "Community Manager",
    avatar: "DK",
    bio: "Community builder and support specialist dedicated to creating an engaging and helpful environment for our users.",
    expertise: ["Community Management", "User Support", "Social Media"],
    social: {
      twitter: "#",
      linkedin: "#",
      email: "david@techreviewpro.com"
    }
  }
]

const stats = [
  { icon: Users, label: "Active Users", value: "50,000+" },
  { icon: BookOpen, label: "Reviews Published", value: "500+" },
  { icon: Star, label: "Average Rating", value: "4.9/5" },
  { icon: Award, label: "Affiliate Partners", value: "100+" }
]

const values = [
  {
    title: "Honesty First",
    description: "We provide unbiased, honest reviews that you can trust. Our recommendations are based on thorough testing and real-world usage.",
    icon: CheckCircle
  },
  {
    title: "User-Centric",
    description: "Everything we do is focused on helping our users make the best decisions for their needs and budget.",
    icon: Heart
  },
  {
    title: "Expert Analysis",
    description: "Our team brings years of experience and expertise to provide in-depth analysis and insights.",
    icon: Target
  }
]

const milestones = [
  { year: "2020", title: "TechReview Pro Founded", description: "Started with a mission to provide honest tech reviews" },
  { year: "2021", title: "First 10,000 Users", description: "Reached our first major milestone with growing community" },
  { year: "2022", title: "Launched Affiliate Program", description: "Partnered with top tech companies to offer exclusive deals" },
  { year: "2023", title: "Expanded to 500+ Reviews", description: "Comprehensive coverage of digital products and services" },
  { year: "2024", title: "Community Forum Launch", description: "Built a thriving community for tech enthusiasts" }
]

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-secondary/10 py-20 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl mb-6">
              About TechReview Pro
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-[800px] mx-auto">
              We're on a mission to help consumers make informed decisions about digital products and services. 
              Through honest reviews, expert analysis, and community engagement, we make technology accessible to everyone.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg">
                Read Our Reviews
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button variant="outline" size="lg">
                Join Community
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 lg:py-24">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => {
              const IconComponent = stat.icon
              return (
                <Card key={index} className="text-center">
                  <CardContent className="p-6">
                    <IconComponent className="h-8 w-8 text-primary mx-auto mb-4" />
                    <div className="text-2xl font-bold mb-2">{stat.value}</div>
                    <div className="text-sm text-muted-foreground">{stat.label}</div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 lg:py-24 bg-muted/30">
        <div className="container px-4 md:px-6">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl mb-4">
                Our Mission & Values
              </h2>
              <p className="text-lg text-muted-foreground">
                The principles that guide everything we do
              </p>
            </div>
            
            <div className="grid gap-8 md:grid-cols-3">
              {values.map((value, index) => {
                const IconComponent = value.icon
                return (
                  <Card key={index} className="text-center">
                    <CardHeader>
                      <IconComponent className="h-12 w-12 text-primary mx-auto mb-4" />
                      <CardTitle className="text-xl">{value.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">{value.description}</p>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 lg:py-24">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl mb-4">
              Meet Our Team
            </h2>
            <p className="text-lg text-muted-foreground">
              The passionate experts behind TechReview Pro
            </p>
          </div>
          
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {teamMembers.map((member, index) => (
              <Card key={index} className="text-center">
                <CardHeader>
                  <Avatar className="h-20 w-20 mx-auto mb-4">
                    <AvatarFallback className="text-lg">{member.avatar}</AvatarFallback>
                  </Avatar>
                  <CardTitle className="text-xl">{member.name}</CardTitle>
                  <Badge variant="secondary" className="w-fit mx-auto">
                    {member.role}
                  </Badge>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{member.bio}</p>
                  
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Expertise:</div>
                    <div className="flex flex-wrap gap-1 justify-center">
                      {member.expertise.map((skill) => (
                        <Badge key={skill} variant="outline" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex justify-center gap-2">
                    <Button variant="ghost" size="sm">
                      <Mail className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Twitter className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Linkedin className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-16 lg:py-24 bg-muted/30">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl mb-4">
              Our Journey
            </h2>
            <p className="text-lg text-muted-foreground">
              Key milestones in our growth story
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <div className="relative">
              <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-border"></div>
              {milestones.map((milestone, index) => (
                <div key={index} className={`flex items-center mb-8 ${index % 2 === 0 ? 'flex-row-reverse' : ''}`}>
                  <div className="w-1/2"></div>
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground text-sm font-bold z-10">
                    {milestone.year.slice(-2)}
                  </div>
                  <div className="w-1/2 px-8">
                    <Card>
                      <CardContent className="p-6">
                        <div className="text-sm text-primary font-medium mb-2">{milestone.year}</div>
                        <h3 className="text-lg font-semibold mb-2">{milestone.title}</h3>
                        <p className="text-sm text-muted-foreground">{milestone.description}</p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 lg:py-24">
        <div className="container px-4 md:px-6">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl mb-4">
                Get in Touch
              </h2>
              <p className="text-lg text-muted-foreground">
                We'd love to hear from you
              </p>
            </div>
            
            <div className="grid gap-8 md:grid-cols-3">
              <Card className="text-center">
                <CardContent className="p-6">
                  <Mail className="h-8 w-8 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Email Us</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Send us a message and we'll get back to you within 24 hours.
                  </p>
                  <a href="mailto:support@techreviewpro.com" className="text-primary hover:underline">
                    support@techreviewpro.com
                  </a>
                </CardContent>
              </Card>
              
              <Card className="text-center">
                <CardContent className="p-6">
                  <Phone className="h-8 w-8 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Call Us</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Monday to Friday, 9 AM to 6 PM EST
                  </p>
                  <a href="tel:+15551234567" className="text-primary hover:underline">
                    +1 (555) 123-4567
                  </a>
                </CardContent>
              </Card>
              
              <Card className="text-center">
                <CardContent className="p-6">
                  <MapPin className="h-8 w-8 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Visit Us</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    123 Tech Street<br />
                    San Francisco, CA 94102
                  </p>
                  <a href="#" className="text-primary hover:underline">
                    Get Directions
                  </a>
                </CardContent>
              </Card>
            </div>
            
            <div className="text-center mt-12">
              <h3 className="text-lg font-semibold mb-4">Follow Us</h3>
              <div className="flex justify-center gap-4">
                <Button variant="outline" size="sm">
                  <Facebook className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm">
                  <Twitter className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm">
                  <Instagram className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm">
                  <Youtube className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm">
                  <Linkedin className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}