'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Progress } from '@/components/ui/progress'
import { 
  BarChart3, 
  Users, 
  FileText, 
  MessageSquare, 
  TrendingUp, 
  DollarSign,
  Eye,
  Heart,
  Star,
  Plus,
  Edit,
  Trash2,
  Search,
  Filter,
  LogOut,
  Settings,
  Bell,
  Menu,
  X
} from 'lucide-react'

const dashboardStats = [
  { title: "Total Posts", value: "252", change: "+12%", icon: FileText, color: "text-blue-600" },
  { title: "Total Users", value: "50,234", change: "+23%", icon: Users, color: "text-green-600" },
  { title: "Total Views", value: "1.2M", change: "+18%", icon: Eye, color: "text-purple-600" },
  { title: "Revenue", value: "$45,678", change: "+34%", icon: DollarSign, color: "text-orange-600" }
]

const recentPosts = [
  {
    id: 1,
    title: "Canva Pro Review: Is It Worth the Upgrade in 2024?",
    author: "Mike Chen",
    status: "published",
    views: 2150,
    likes: 89,
    comments: 15,
    publishedAt: "2 hours ago"
  },
  {
    id: 2,
    title: "Notion vs Obsidian: Which Note-Taking App is Right for You?",
    author: "Sarah Johnson",
    status: "published",
    views: 3420,
    likes: 145,
    comments: 23,
    publishedAt: "5 hours ago"
  },
  {
    id: 3,
    title: "Webflow vs Framer: Best Website Builder for Designers",
    author: "Emily Davis",
    status: "draft",
    views: 0,
    likes: 0,
    comments: 0,
    publishedAt: "1 day ago"
  }
]

const recentUsers = [
  {
    id: 1,
    name: "John Doe",
    email: "john@example.com",
    role: "User",
    joinedAt: "2 hours ago",
    posts: 5,
    status: "active"
  },
  {
    id: 2,
    name: "Jane Smith",
    email: "jane@example.com",
    role: "User",
    joinedAt: "5 hours ago",
    posts: 12,
    status: "active"
  },
  {
    id: 3,
    name: "Bob Wilson",
    email: "bob@example.com",
    role: "Admin",
    joinedAt: "1 day ago",
    posts: 28,
    status: "active"
  }
]

const topPerformingPosts = [
  {
    title: "Adobe Creative Cloud All Apps Review",
    views: 4560,
    revenue: "$1,234",
    conversionRate: "3.2%"
  },
  {
    title: "Kajabi Review: The Ultimate Course Platform Analysis",
    views: 5230,
    revenue: "$2,456",
    conversionRate: "4.7%"
  },
  {
    title: "ClickFunnels vs Leadpages: Which is Better?",
    views: 2780,
    revenue: "$987",
    conversionRate: "2.8%"
  }
]

export default function AdminDashboard() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(false)

  useEffect(() => {
    const authStatus = localStorage.getItem('adminAuthenticated')
    if (authStatus !== 'true') {
      router.push('/admin')
    } else {
      setIsAuthenticated(true)
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem('adminAuthenticated')
    router.push('/admin')
  }

  if (!isAuthenticated) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-16 items-center px-4">
          <Button
            variant="ghost"
            size="sm"
            className="md:hidden"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            {sidebarOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </Button>
          
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center space-x-4">
              <h1 className="text-xl font-semibold">Admin Dashboard</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Settings className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className={`w-64 border-r bg-muted/30 p-4 ${sidebarOpen ? 'block' : 'hidden md:block'}`}>
          <nav className="space-y-2">
            <Button variant="ghost" className="w-full justify-start">
              <BarChart3 className="mr-2 h-4 w-4" />
              Dashboard
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <FileText className="mr-2 h-4 w-4" />
              Posts
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Users className="mr-2 h-4 w-4" />
              Users
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <MessageSquare className="mr-2 h-4 w-4" />
              Comments
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <DollarSign className="mr-2 h-4 w-4" />
              Affiliate Links
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <TrendingUp className="mr-2 h-4 w-4" />
              Analytics
            </Button>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          <div className="space-y-6">
            {/* Stats Cards */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              {dashboardStats.map((stat, index) => {
                const IconComponent = stat.icon
                return (
                  <Card key={index}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                          <p className="text-2xl font-bold">{stat.value}</p>
                          <p className={`text-xs ${stat.color}`}>{stat.change}</p>
                        </div>
                        <IconComponent className={`h-8 w-8 ${stat.color}`} />
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            {/* Charts and Analytics */}
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Revenue Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between text-sm">
                      <span>This Month</span>
                      <span className="font-medium">$12,345</span>
                    </div>
                    <Progress value={67} className="h-2" />
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>67% of goal</span>
                      <span>Goal: $18,000</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Top Performing Posts</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {topPerformingPosts.map((post, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{post.title}</p>
                          <p className="text-xs text-muted-foreground">{post.views} views</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium">{post.revenue}</p>
                          <p className="text-xs text-muted-foreground">{post.conversionRate}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Tabs defaultValue="posts" className="w-full">
              <TabsList>
                <TabsTrigger value="posts">Recent Posts</TabsTrigger>
                <TabsTrigger value="users">Recent Users</TabsTrigger>
                <TabsTrigger value="comments">Comments</TabsTrigger>
              </TabsList>
              
              <TabsContent value="posts">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>Recent Posts</CardTitle>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Search className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Filter className="h-4 w-4" />
                        </Button>
                        <Button size="sm">
                          <Plus className="h-4 w-4" />
                          New Post
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentPosts.map((post) => (
                        <div key={post.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium truncate">{post.title}</h3>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                              <span>By {post.author}</span>
                              <span>•</span>
                              <span>{post.publishedAt}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="flex items-center gap-2 text-sm">
                              <Eye className="h-4 w-4" />
                              <span>{post.views}</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm">
                              <Heart className="h-4 w-4" />
                              <span>{post.likes}</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm">
                              <MessageSquare className="h-4 w-4" />
                              <span>{post.comments}</span>
                            </div>
                            <Badge variant={post.status === 'published' ? 'default' : 'secondary'}>
                              {post.status}
                            </Badge>
                            <div className="flex gap-1">
                              <Button variant="ghost" size="sm">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="users">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>Recent Users</CardTitle>
                      <Button size="sm">
                        <Plus className="h-4 w-4" />
                        Add User
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentUsers.map((user) => (
                        <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-10 w-10">
                              <AvatarFallback>{user.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                            </Avatar>
                            <div>
                              <h3 className="font-medium">{user.name}</h3>
                              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                <span>{user.email}</span>
                                <span>•</span>
                                <span>{user.posts} posts</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <Badge variant={user.role === 'Admin' ? 'default' : 'secondary'}>
                              {user.role}
                            </Badge>
                            <Badge variant="outline" className="text-green-600">
                              {user.status}
                            </Badge>
                            <span className="text-sm text-muted-foreground">{user.joinedAt}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="comments">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Comments</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8 text-muted-foreground">
                      <MessageSquare className="h-12 w-12 mx-auto mb-4" />
                      <p>No comments yet</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  )
}