import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Search, Plus, MessageCircle, ThumbsUp, Eye, Pin, Lock, TrendingUp, Clock, Users, Calendar, ArrowRight } from 'lucide-react'

const forumCategories = [
  { id: 1, name: "General Discussion", description: "General chat and introductions", postCount: 145, color: "bg-blue-500" },
  { id: 2, name: "Product Reviews", description: "Share and discuss product reviews", postCount: 89, color: "bg-green-500" },
  { id: 3, name: "Help & Support", description: "Get help from the community", postCount: 67, color: "bg-purple-500" },
  { id: 4, name: "Feature Requests", description: "Suggest new features and improvements", postCount: 34, color: "bg-orange-500" },
  { id: 5, name: "Off-Topic", description: "Random discussions and fun", postCount: 78, color: "bg-pink-500" }
]

const forumPosts = [
  {
    id: 1,
    title: "Best AI writing tools for content creators in 2024?",
    excerpt: "Looking for recommendations on AI writing assistants. What's working well for you guys?",
    author: "Sarah Johnson",
    authorAvatar: "SJ",
    category: "Product Reviews",
    replies: 23,
    views: 1542,
    likes: 45,
    isPinned: true,
    isLocked: false,
    createdAt: "2 hours ago",
    lastActivity: "10 minutes ago",
    tags: ["AI", "Writing", "Tools"]
  },
  {
    id: 2,
    title: "How to choose the right design software for beginners?",
    excerpt: "I'm new to design and overwhelmed by the options. Can anyone help me understand the differences?",
    author: "Mike Chen",
    authorAvatar: "MC",
    category: "Help & Support",
    replies: 18,
    views: 892,
    likes: 32,
    isPinned: false,
    isLocked: false,
    createdAt: "5 hours ago",
    lastActivity: "1 hour ago",
    tags: ["Design", "Beginner", "Help"]
  },
  {
    id: 3,
    title: "Welcome to the TechReview Pro Community! 🎉",
    excerpt: "Introduce yourself here and let us know what you're interested in. We're excited to have you!",
    author: "Admin",
    authorAvatar: "AD",
    category: "General Discussion",
    replies: 156,
    views: 5234,
    likes: 89,
    isPinned: true,
    isLocked: false,
    createdAt: "1 week ago",
    lastActivity: "30 minutes ago",
    tags: ["Welcome", "Introduction"]
  },
  {
    id: 4,
    title: "Can we get a dark mode feature?",
    excerpt: "I love the platform but would really appreciate a dark mode option for late-night browsing.",
    author: "Emily Davis",
    authorAvatar: "ED",
    category: "Feature Requests",
    replies: 12,
    views: 445,
    likes: 28,
    isPinned: false,
    isLocked: false,
    createdAt: "1 day ago",
    lastActivity: "3 hours ago",
    tags: ["Feature", "Dark Mode"]
  },
  {
    id: 5,
    title: "Share your favorite productivity hacks!",
    excerpt: "Let's compile a list of the best productivity tips and tricks. What works for you?",
    author: "David Kim",
    authorAvatar: "DK",
    category: "General Discussion",
    replies: 67,
    views: 2103,
    likes: 94,
    isPinned: false,
    isLocked: false,
    createdAt: "3 days ago",
    lastActivity: "2 hours ago",
    tags: ["Productivity", "Tips", "Community"]
  },
  {
    id: 6,
    title: "Important: Community Guidelines Update",
    excerpt: "We've updated our community guidelines. Please take a moment to review the changes.",
    author: "Admin",
    authorAvatar: "AD",
    category: "General Discussion",
    replies: 8,
    views: 1876,
    likes: 15,
    isPinned: true,
    isLocked: true,
    createdAt: "2 days ago",
    lastActivity: "1 day ago",
    tags: ["Guidelines", "Important"]
  }
]

const recentActivity = [
  {
    id: 1,
    action: "replied to",
    target: "Best AI writing tools for content creators",
    user: "John Doe",
    time: "2 minutes ago",
    avatar: "JD"
  },
  {
    id: 2,
    action: "posted in",
    target: "General Discussion",
    user: "Jane Smith",
    time: "5 minutes ago",
    avatar: "JS"
  },
  {
    id: 3,
    action: "liked",
    target: "How to choose design software",
    user: "Bob Wilson",
    time: "8 minutes ago",
    avatar: "BW"
  },
  {
    id: 4,
    action: "joined",
    target: "the community",
    user: "Alice Brown",
    time: "15 minutes ago",
    avatar: "AB"
  }
]

const topContributors = [
  { name: "Sarah Johnson", avatar: "SJ", posts: 45, likes: 234 },
  { name: "Mike Chen", avatar: "MC", posts: 38, likes: 189 },
  { name: "Emily Davis", avatar: "ED", posts: 32, likes: 156 },
  { name: "David Kim", avatar: "DK", posts: 28, likes: 143 }
]

export default function ForumPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container px-4 md:px-6 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl mb-4">
            Community Forum
          </h1>
          <p className="text-xl text-muted-foreground max-w-[700px] mx-auto mb-8">
            Connect with fellow tech enthusiasts, share experiences, and get help from our amazing community.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 max-w-2xl mx-auto mb-8">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search discussions..."
                className="pl-10"
              />
            </div>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Discussion
            </Button>
          </div>
        </div>

        {/* Forum Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-2xl font-bold text-primary">1,234</div>
              <div className="text-sm text-muted-foreground">Members</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-2xl font-bold text-primary">456</div>
              <div className="text-sm text-muted-foreground">Discussions</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-2xl font-bold text-primary">2,890</div>
              <div className="text-sm text-muted-foreground">Replies</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-2xl font-bold text-primary">89</div>
              <div className="text-sm text-muted-foreground">Online Now</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
          {/* Main Content */}
          <div className="space-y-6">
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="all">All Posts</TabsTrigger>
                <TabsTrigger value="trending">Trending</TabsTrigger>
                <TabsTrigger value="pinned">Pinned</TabsTrigger>
                <TabsTrigger value="recent">Recent</TabsTrigger>
              </TabsList>
              
              <TabsContent value="all" className="space-y-4">
                {forumPosts.map((post) => (
                  <Card key={post.id} className="hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className="text-sm">{post.authorAvatar}</AvatarFallback>
                        </Avatar>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2">
                            {post.isPinned && <Pin className="h-4 w-4 text-primary" />}
                            {post.isLocked && <Lock className="h-4 w-4 text-muted-foreground" />}
                            <Badge variant="secondary" className="text-xs">{post.category}</Badge>
                            <span className="text-xs text-muted-foreground">{post.createdAt}</span>
                          </div>
                          
                          <h3 className="font-semibold text-lg mb-2 hover:text-primary transition-colors">
                            {post.title}
                          </h3>
                          
                          <p className="text-muted-foreground mb-3 line-clamp-2">
                            {post.excerpt}
                          </p>
                          
                          <div className="flex flex-wrap gap-1 mb-3">
                            {post.tags.map((tag) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                          
                          <div className="flex items-center justify-between text-sm text-muted-foreground">
                            <div className="flex items-center gap-4">
                              <span className="font-medium">{post.author}</span>
                              <span>•</span>
                              <span>Last activity {post.lastActivity}</span>
                            </div>
                            
                            <div className="flex items-center gap-4">
                              <div className="flex items-center gap-1">
                                <MessageCircle className="h-4 w-4" />
                                <span>{post.replies}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Eye className="h-4 w-4" />
                                <span>{post.views}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <ThumbsUp className="h-4 w-4" />
                                <span>{post.likes}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
              
              <TabsContent value="trending" className="space-y-4">
                {forumPosts.filter(post => post.likes > 30).map((post) => (
                  <Card key={post.id} className="hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="h-4 w-4 text-primary" />
                        <Badge variant="secondary" className="text-xs">{post.category}</Badge>
                        <span className="text-xs text-muted-foreground">{post.createdAt}</span>
                      </div>
                      <h3 className="font-semibold text-lg mb-2">{post.title}</h3>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>{post.author}</span>
                        <div className="flex items-center gap-1">
                          <ThumbsUp className="h-4 w-4" />
                          <span>{post.likes}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <MessageCircle className="h-4 w-4" />
                          <span>{post.replies}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
              
              <TabsContent value="pinned" className="space-y-4">
                {forumPosts.filter(post => post.isPinned).map((post) => (
                  <Card key={post.id} className="hover:shadow-md transition-shadow cursor-pointer border-primary">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-2 mb-2">
                        <Pin className="h-4 w-4 text-primary" />
                        <Badge variant="default" className="text-xs">Pinned</Badge>
                        <Badge variant="secondary" className="text-xs">{post.category}</Badge>
                      </div>
                      <h3 className="font-semibold text-lg mb-2">{post.title}</h3>
                      <p className="text-muted-foreground mb-3 line-clamp-2">{post.excerpt}</p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>{post.author}</span>
                        <div className="flex items-center gap-1">
                          <MessageCircle className="h-4 w-4" />
                          <span>{post.replies}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Eye className="h-4 w-4" />
                          <span>{post.views}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
              
              <TabsContent value="recent" className="space-y-4">
                {forumPosts.slice(0, 3).map((post) => (
                  <Card key={post.id} className="hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-2 mb-2">
                        <Clock className="h-4 w-4 text-primary" />
                        <Badge variant="secondary" className="text-xs">{post.category}</Badge>
                        <span className="text-xs text-muted-foreground">{post.createdAt}</span>
                      </div>
                      <h3 className="font-semibold text-lg mb-2">{post.title}</h3>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>{post.author}</span>
                        <div className="flex items-center gap-1">
                          <MessageCircle className="h-4 w-4" />
                          <span>{post.replies}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Categories */}
            <Card>
              <CardHeader>
                <CardTitle>Categories</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {forumCategories.map((category) => (
                  <div key={category.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 cursor-pointer">
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${category.color}`}></div>
                      <div>
                        <div className="font-medium text-sm">{category.name}</div>
                        <div className="text-xs text-muted-foreground">{category.description}</div>
                      </div>
                    </div>
                    <Badge variant="secondary" className="text-xs">{category.postCount}</Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-center gap-3">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="text-xs">{activity.avatar}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm">
                        <span className="font-medium">{activity.user}</span>
                        <span className="text-muted-foreground"> {activity.action} </span>
                        <span className="text-muted-foreground line-clamp-1">{activity.target}</span>
                      </div>
                      <div className="text-xs text-muted-foreground">{activity.time}</div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Top Contributors */}
            <Card>
              <CardHeader>
                <CardTitle>Top Contributors</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {topContributors.map((contributor, index) => (
                  <div key={contributor.name} className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold">
                      {index + 1}
                    </div>
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="text-xs">{contributor.avatar}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm">{contributor.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {contributor.posts} posts • {contributor.likes} likes
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Links</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="ghost" className="w-full justify-start">
                  <Users className="mr-2 h-4 w-4" />
                  Community Guidelines
                </Button>
                <Button variant="ghost" className="w-full justify-start">
                  <Calendar className="mr-2 h-4 w-4" />
                  Upcoming Events
                </Button>
                <Button variant="ghost" className="w-full justify-start">
                  <MessageCircle className="mr-2 h-4 w-4" />
                  Help Center
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}