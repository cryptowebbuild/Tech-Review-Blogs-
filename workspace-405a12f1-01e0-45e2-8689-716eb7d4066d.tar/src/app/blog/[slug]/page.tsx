import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Star, Clock, Eye, Heart, MessageCircle, Share2, Calendar, User, Tag, CheckCircle, AlertCircle, ShoppingCart, ExternalLink } from 'lucide-react'

const post = {
  id: 1,
  title: "Canva Pro Review: Is It Worth the Upgrade in 2024?",
  excerpt: "Complete analysis of Canva Pro features, pricing, and whether it's worth upgrading from the free version.",
  content: `
    <h2>Introduction</h2>
    <p>Canva has become one of the most popular design tools in the world, with over 135 million monthly active users. But is the Pro version worth the money? In this comprehensive review, we'll break down everything you need to know.</p>
    
    <h2>What is Canva Pro?</h2>
    <p>Canva Pro is the premium version of Canva that offers advanced features for professionals and businesses. It builds upon the free version with additional tools, resources, and capabilities.</p>
    
    <h2>Key Features</h2>
    <ul>
      <li><strong>Brand Kit:</strong> Upload your brand colors, fonts, and logos</li>
      <li><strong>Background Remover:</strong> Remove image backgrounds with one click</li>
      <li><strong>Premium Templates:</strong> Access to 400,000+ premium templates</li>
      <li><strong>Team Collaboration:</strong> Work together with your team in real-time</li>
      <li><strong>Content Planner:</strong> Schedule social media posts directly</li>
    </ul>
    
    <h2>Pricing</h2>
    <p>Canva Pro costs $119.99 per year (billed annually) or $12.99 per month (billed monthly). There's also a 30-day free trial available.</p>
    
    <h2>Who is it for?</h2>
    <p>Canva Pro is ideal for:</p>
    <ul>
      <li>Small business owners who need professional designs</li>
      <li>Social media managers handling multiple accounts</li>
      <li>Marketing teams requiring brand consistency</li>
      <li>Content creators looking to streamline their workflow</li>
    </ul>
    
    <h2>Pros and Cons</h2>
    <p><strong>Pros:</strong></p>
    <ul>
      <li>Easy to use interface</li>
      <li>Excellent value for money</li>
      <li>Massive template library</li>
      <li>Great collaboration features</li>
    </ul>
    
    <p><strong>Cons:</strong></p>
    <ul>
      <li>Limited advanced design features</li>
      <li>Not suitable for complex print design</li>
      <li>Requires internet connection</li>
    </ul>
    
    <h2>Final Verdict</h2>
    <p>Canva Pro offers excellent value for most users who need professional designs without the complexity of Adobe Creative Suite. The Brand Kit feature alone makes it worth the investment for businesses.</p>
  `,
  author: {
    name: "Mike Chen",
    avatar: "MC",
    bio: "Design enthusiast and tech reviewer with 10+ years of experience in digital marketing and brand design."
  },
  category: "Design Tools",
  tags: ["Design", "Canva", "Review", "Graphic Design"],
  image: "/api/placeholder/1200/600",
  publishedAt: "2024-01-15",
  updatedAt: "2024-01-15",
  readingTime: 8,
  viewCount: 2150,
  rating: 4.7,
  likes: 89,
  comments: 15,
  featured: true
}

const affiliateProducts = [
  {
    id: 1,
    name: "Canva Pro",
    description: "Professional design platform with advanced features",
    price: "$12.99/month",
    discountPrice: "$119.99/year",
    rating: 4.7,
    image: "/api/placeholder/200/120",
    features: ["Brand Kit", "Background Remover", "Premium Templates", "Team Collaboration"],
    affiliateLink: "https://www.canva.com/pro/",
    buttonText: "Start Free Trial",
    commission: "Earn 20% commission",
    pros: ["Easy to use", "Great value", "Excellent templates"],
    cons: ["Limited advanced features", "Requires internet"]
  },
  {
    id: 2,
    name: "Adobe Creative Cloud",
    description: "Professional creative suite for advanced designers",
    price: "$54.99/month",
    discountPrice: "$599.88/year",
    rating: 4.8,
    image: "/api/placeholder/200/120",
    features: ["Photoshop", "Illustrator", "InDesign", "Premiere Pro"],
    affiliateLink: "https://www.adobe.com/creativecloud.html",
    buttonText: "Get Adobe CC",
    commission: "Earn 15% commission",
    pros: ["Industry standard", "Advanced features", "Professional tools"],
    cons: ["Expensive", "Steep learning curve"]
  },
  {
    id: 3,
    name: "Figma Pro",
    description: "Collaborative interface design tool",
    price: "$15/month",
    discountPrice: "$144/year",
    rating: 4.6,
    image: "/api/placeholder/200/120",
    features: ["Real-time collaboration", "Prototyping", "Design systems", "Version control"],
    affiliateLink: "https://www.figma.com/pricing/",
    buttonText: "Try Figma Pro",
    commission: "Earn 25% commission",
    pros: ["Excellent collaboration", "Great for UI/UX", "Free tier available"],
    cons: ["Not for print design", "Limited image editing"]
  }
]

const relatedPosts = [
  {
    id: 2,
    title: "Figma vs Sketch: The Ultimate Design Tool Comparison",
    excerpt: "Comprehensive comparison of two popular design tools for UI/UX designers.",
    image: "/api/placeholder/300/200",
    category: "Design Tools",
    readTime: 12,
    publishedAt: "3 days ago"
  },
  {
    id: 3,
    title: "Best Free Design Tools for Beginners",
    excerpt: "Discover the best free design tools that don't compromise on features.",
    image: "/api/placeholder/300/200",
    category: "Design Tools",
    readTime: 10,
    publishedAt: "1 week ago"
  }
]

export default function BlogPostPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container px-4 md:px-6 py-8">
        {/* Article Header */}
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Badge variant="secondary">{post.category}</Badge>
              {post.featured && (
                <Badge variant="default">Featured</Badge>
              )}
            </div>
            
            <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl mb-4">
              {post.title}
            </h1>
            
            <p className="text-xl text-muted-foreground mb-6">
              {post.excerpt}
            </p>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Avatar className="h-12 w-12">
                  <AvatarFallback>{post.author.avatar}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-medium">{post.author.name}</div>
                  <div className="text-sm text-muted-foreground">
                    {new Date(post.publishedAt).toLocaleDateString()} • {post.readingTime} min read
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span className="font-medium text-foreground">{post.rating}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Eye className="h-4 w-4" />
                  <span>{post.viewCount.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Heart className="h-4 w-4" />
                  <span>{post.likes}</span>
                </div>
                <div className="flex items-center gap-1">
                  <MessageCircle className="h-4 w-4" />
                  <span>{post.comments}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Featured Image */}
          <div className="mb-8">
            <img 
              src={post.image} 
              alt={post.title}
              className="w-full h-[400px] object-cover rounded-lg"
            />
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-2 mb-8">
            {post.tags.map((tag) => (
              <Badge key={tag} variant="outline">
                <Tag className="mr-1 h-3 w-3" />
                {tag}
              </Badge>
            ))}
          </div>

          <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
            {/* Main Content */}
            <div className="space-y-8">
              {/* Article Content */}
              <Card>
                <CardContent className="p-8">
                  <div 
                    className="prose prose-lg max-w-none"
                    dangerouslySetInnerHTML={{ __html: post.content }}
                  />
                </CardContent>
              </Card>

              {/* Affiliate Products Section */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ShoppingCart className="h-5 w-5" />
                    Recommended Products
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {affiliateProducts.map((product) => (
                    <div key={product.id} className="border rounded-lg p-4 space-y-4">
                      <div className="flex items-start gap-4">
                        <img 
                          src={product.image} 
                          alt={product.name}
                          className="w-20 h-12 object-cover rounded"
                        />
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg">{product.name}</h3>
                          <p className="text-sm text-muted-foreground mb-2">{product.description}</p>
                          <div className="flex items-center gap-2 mb-2">
                            <div className="flex items-center gap-1">
                              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                              <span className="font-medium">{product.rating}</span>
                            </div>
                            <span className="text-sm text-muted-foreground">•</span>
                            <span className="text-sm font-medium text-primary">{product.price}</span>
                            {product.discountPrice && (
                              <>
                                <span className="text-sm text-muted-foreground">•</span>
                                <span className="text-sm text-green-600">{product.discountPrice}</span>
                              </>
                            )}
                          </div>
                          <div className="flex flex-wrap gap-1 mb-3">
                            {product.features.map((feature) => (
                              <Badge key={feature} variant="secondary" className="text-xs">
                                {feature}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      
                      <Tabs defaultValue="overview" className="w-full">
                        <TabsList className="grid w-full grid-cols-3">
                          <TabsTrigger value="overview">Overview</TabsTrigger>
                          <TabsTrigger value="pros-cons">Pros & Cons</TabsTrigger>
                          <TabsTrigger value="commission">Commission</TabsTrigger>
                        </TabsList>
                        <TabsContent value="overview" className="mt-2">
                          <p className="text-sm text-muted-foreground">{product.description}</p>
                        </TabsContent>
                        <TabsContent value="pros-cons" className="mt-2">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <div className="flex items-center gap-1 text-green-600 mb-2">
                                <CheckCircle className="h-4 w-4" />
                                <span className="font-medium">Pros</span>
                              </div>
                              <ul className="space-y-1">
                                {product.pros.map((pro) => (
                                  <li key={pro} className="text-muted-foreground">• {pro}</li>
                                ))}
                              </ul>
                            </div>
                            <div>
                              <div className="flex items-center gap-1 text-red-600 mb-2">
                                <AlertCircle className="h-4 w-4" />
                                <span className="font-medium">Cons</span>
                              </div>
                              <ul className="space-y-1">
                                {product.cons.map((con) => (
                                  <li key={con} className="text-muted-foreground">• {con}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </TabsContent>
                        <TabsContent value="commission" className="mt-2">
                          <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                            <p className="text-sm text-green-800">
                              <strong>Affiliate Opportunity:</strong> {product.commission}
                            </p>
                          </div>
                        </TabsContent>
                      </Tabs>
                      
                      <div className="flex gap-2">
                        <Button className="flex-1">
                          <ExternalLink className="mr-2 h-4 w-4" />
                          {product.buttonText}
                        </Button>
                        <Button variant="outline" size="sm">
                          <Share2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Related Posts */}
              <Card>
                <CardHeader>
                  <CardTitle>Related Posts</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {relatedPosts.map((relatedPost) => (
                    <div key={relatedPost.id} className="flex gap-4 p-4 border rounded-lg hover:bg-muted/50 cursor-pointer">
                      <img 
                        src={relatedPost.image} 
                        alt={relatedPost.title}
                        className="w-24 h-16 object-cover rounded"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold mb-1 line-clamp-2">{relatedPost.title}</h3>
                        <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{relatedPost.excerpt}</p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Badge variant="secondary" className="text-xs">{relatedPost.category}</Badge>
                          <span>•</span>
                          <span>{relatedPost.readTime} min read</span>
                          <span>•</span>
                          <span>{relatedPost.publishedAt}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Author Card */}
              <Card>
                <CardHeader>
                  <CardTitle>About the Author</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <Avatar className="h-16 w-16 mx-auto mb-4">
                    <AvatarFallback className="text-lg">{post.author.avatar}</AvatarFallback>
                  </Avatar>
                  <h3 className="font-semibold mb-2">{post.author.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{post.author.bio}</p>
                  <Button variant="outline" size="sm">Follow Author</Button>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button variant="outline" className="w-full justify-start">
                    <Heart className="mr-2 h-4 w-4" />
                    Like this post
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Share2 className="mr-2 h-4 w-4" />
                    Share this post
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Leave a comment
                  </Button>
                </CardContent>
              </Card>

              {/* Newsletter */}
              <Card>
                <CardHeader>
                  <CardTitle>Stay Updated</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Get the latest reviews and exclusive deals delivered to your inbox.
                  </p>
                  <Button className="w-full">Subscribe Now</Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}