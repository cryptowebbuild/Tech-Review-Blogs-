import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Search, Filter, Calendar, Star, Clock, Eye, Heart, MessageCircle, ArrowRight, Grid, List } from 'lucide-react'

const blogPosts = [
  {
    id: 1,
    title: "Notion vs Obsidian: Which Note-Taking App is Right for You?",
    excerpt: "In-depth comparison of two powerful note-taking applications with different approaches to knowledge management. We'll break down features, pricing, and use cases to help you choose.",
    author: "Sarah Johnson",
    authorAvatar: "SJ",
    category: "Productivity",
    tags: ["Note-taking", "Productivity", "Comparison"],
    image: "/api/placeholder/400/250",
    rating: 4.5,
    readTime: 10,
    views: 3420,
    publishedAt: "2 hours ago",
    likes: 145,
    comments: 23,
    featured: true,
    affiliate: false
  },
  {
    id: 2,
    title: "Canva Pro Review: Is It Worth the Upgrade in 2024?",
    excerpt: "Complete analysis of Canva Pro features, pricing, and whether it's worth upgrading from the free version. Includes real-world testing and use case scenarios.",
    author: "Mike Chen",
    authorAvatar: "MC",
    category: "Design Tools",
    tags: ["Design", "Canva", "Review"],
    image: "/api/placeholder/400/250",
    rating: 4.7,
    readTime: 8,
    views: 2150,
    publishedAt: "5 hours ago",
    likes: 89,
    comments: 15,
    featured: false,
    affiliate: true
  },
  {
    id: 3,
    title: "Webflow vs Framer: Best Website Builder for Designers",
    excerpt: "Comprehensive comparison of two popular website builders focused on design flexibility and ease of use. Perfect for designers deciding between these platforms.",
    author: "Emily Davis",
    authorAvatar: "ED",
    category: "Web Development",
    tags: ["Web Design", "Website Builders", "Comparison"],
    image: "/api/placeholder/400/250",
    rating: 4.6,
    readTime: 12,
    views: 1890,
    publishedAt: "1 day ago",
    likes: 67,
    comments: 8,
    featured: false,
    affiliate: true
  },
  {
    id: 4,
    title: "Adobe Creative Cloud All Apps Review: Value Analysis",
    excerpt: "Breaking down the value proposition of Adobe's complete creative suite and who should actually subscribe. Includes alternative recommendations.",
    author: "Alex Rivera",
    authorAvatar: "AR",
    category: "Creative Software",
    tags: ["Adobe", "Creative Cloud", "Review"],
    image: "/api/placeholder/400/250",
    rating: 4.4,
    readTime: 15,
    views: 4560,
    publishedAt: "2 days ago",
    likes: 234,
    comments: 41,
    featured: true,
    affiliate: true
  },
  {
    id: 5,
    title: "ClickFunnels vs Leadpages: Which is Better for Your Business?",
    excerpt: "Detailed comparison of two leading landing page builders to help you choose the right platform for your business needs and budget.",
    author: "David Kim",
    authorAvatar: "DK",
    category: "Marketing Tools",
    tags: ["Marketing", "Landing Pages", "Comparison"],
    image: "/api/placeholder/400/250",
    rating: 4.3,
    readTime: 9,
    views: 2780,
    publishedAt: "3 days ago",
    likes: 156,
    comments: 29,
    featured: false,
    affiliate: true
  },
  {
    id: 6,
    title: "Kajabi Review: The Ultimate Course Platform Analysis",
    excerpt: "Is Kajabi worth the investment? Complete breakdown of features, pricing, and alternatives for course creators and digital entrepreneurs.",
    author: "Lisa Thompson",
    authorAvatar: "LT",
    category: "Online Courses",
    tags: ["Kajabi", "Course Platform", "Review"],
    image: "/api/placeholder/400/250",
    rating: 4.7,
    readTime: 15,
    views: 5230,
    publishedAt: "4 days ago",
    likes: 289,
    comments: 52,
    featured: true,
    affiliate: true
  }
]

const categories = [
  "All Categories",
  "AI Tools",
  "Design Tools",
  "Web Development",
  "Marketing Tools",
  "Online Courses",
  "Creative Software",
  "Productivity"
]

const tags = [
  "Review",
  "Comparison",
  "Tutorial",
  "AI Tools",
  "Design",
  "Marketing",
  "Productivity",
  "Web Development"
]

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container px-4 md:px-6 py-8">
        {/* Header Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl mb-4">
            Latest Reviews
          </h1>
          <p className="text-xl text-muted-foreground max-w-[700px] mx-auto">
            Honest, in-depth reviews of digital products, software, and online courses. 
            Make informed decisions with our expert analysis.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="mb-8">
          <div className="flex flex-col lg:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search reviews, products, or categories..."
                className="pl-10"
              />
            </div>
            
            <div className="flex gap-2">
              <Select>
                <SelectTrigger className="w-full lg:w-[180px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category.toLowerCase()}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select>
                <SelectTrigger className="w-full lg:w-[140px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="latest">Latest</SelectItem>
                  <SelectItem value="popular">Most Popular</SelectItem>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                  <SelectItem value="trending">Trending</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Tags Filter */}
          <div className="flex flex-wrap gap-2 mb-6">
            <span className="text-sm text-muted-foreground self-center mr-2">Popular tags:</span>
            {tags.map((tag) => (
              <Badge key={tag} variant="secondary" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
                {tag}
              </Badge>
            ))}
          </div>

          {/* View Toggle */}
          <div className="flex items-center justify-between mb-6">
            <div className="text-sm text-muted-foreground">
              Showing <span className="font-medium">6</span> of <span className="font-medium">252</span> reviews
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Grid className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Blog Posts Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {blogPosts.map((post) => (
            <Card key={post.id} className="group hover:shadow-lg transition-all duration-300 overflow-hidden">
              <div className="relative">
                <div className="aspect-video bg-muted">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="absolute top-4 left-4 flex gap-2">
                  <Badge variant="secondary">{post.category}</Badge>
                  {post.featured && (
                    <Badge variant="default">Featured</Badge>
                  )}
                  {post.affiliate && (
                    <Badge variant="destructive">Affiliate</Badge>
                  )}
                </div>
              </div>
              
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                  <Calendar className="h-4 w-4" />
                  <span>{post.publishedAt}</span>
                  <div className="h-1 w-1 bg-muted-foreground rounded-full"></div>
                  <Clock className="h-4 w-4" />
                  <span>{post.readTime} min read</span>
                </div>
                
                <CardTitle className="line-clamp-2 group-hover:text-primary transition-colors">
                  {post.title}
                </CardTitle>
                
                <p className="text-muted-foreground text-sm line-clamp-3">
                  {post.excerpt}
                </p>
              </CardHeader>
              
              <CardContent className="pt-0">
                <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="font-medium text-foreground">{post.rating}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Eye className="h-4 w-4" />
                    <span>{post.views.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Heart className="h-4 w-4" />
                    <span>{post.likes}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MessageCircle className="h-4 w-4" />
                    <span>{post.comments}</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarFallback className="text-xs">{post.authorAvatar}</AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-medium">{post.author}</span>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-1 mb-4">
                  {post.tags.slice(0, 3).map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
                
                <Button className="w-full">
                  Read Full Review
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-center mt-12">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" disabled>
              Previous
            </Button>
            <Button variant="default" size="sm">1</Button>
            <Button variant="outline" size="sm">2</Button>
            <Button variant="outline" size="sm">3</Button>
            <Button variant="outline" size="sm">...</Button>
            <Button variant="outline" size="sm">42</Button>
            <Button variant="outline" size="sm">
              Next
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}