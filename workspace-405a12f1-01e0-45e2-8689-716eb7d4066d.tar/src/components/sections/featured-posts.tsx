import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Star, Clock, Eye, ArrowRight } from 'lucide-react'

const featuredPosts = [
  {
    id: 1,
    title: "Best AI Writing Tools for Content Creators in 2024",
    excerpt: "Comprehensive review of the top AI writing assistants that can help you create better content faster.",
    category: "AI Tools",
    image: "/api/placeholder/400/250",
    rating: 4.8,
    readTime: 12,
    views: 15420,
    featured: true,
    price: "$9.99 - $99/month",
    affiliateLink: true
  },
  {
    id: 2,
    title: "ClickFunnels vs Leadpages: Which is Better for Your Business?",
    excerpt: "Detailed comparison of two leading landing page builders to help you choose the right platform.",
    category: "Marketing Tools",
    image: "/api/placeholder/400/250",
    rating: 4.6,
    readTime: 8,
    views: 8930,
    featured: true,
    price: "$37 - $297/month",
    affiliateLink: true
  },
  {
    id: 3,
    title: "Kajabi Review: The Ultimate Course Platform Analysis",
    excerpt: "Is Kajabi worth the investment? Complete breakdown of features, pricing, and alternatives.",
    category: "Online Courses",
    image: "/api/placeholder/400/250",
    rating: 4.7,
    readTime: 15,
    views: 12150,
    featured: true,
    price: "$149 - $399/month",
    affiliateLink: true
  }
]

export function FeaturedPosts() {
  return (
    <section className="py-16 lg:py-24">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
            Featured Reviews
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-[700px] mx-auto">
            Our most popular and comprehensive reviews of digital products and services
          </p>
        </div>
        
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {featuredPosts.map((post) => (
            <Card key={post.id} className="group hover:shadow-lg transition-all duration-300 overflow-hidden">
              <div className="relative">
                <div className="aspect-video bg-muted">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="absolute top-4 left-4">
                  <Badge variant="secondary">{post.category}</Badge>
                </div>
                {post.affiliateLink && (
                  <div className="absolute top-4 right-4">
                    <Badge variant="destructive" className="text-xs">
                      Affiliate
                    </Badge>
                  </div>
                )}
              </div>
              
              <CardHeader className="pb-3">
                <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="font-medium text-foreground">{post.rating}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{post.readTime} min</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Eye className="h-4 w-4" />
                    <span>{post.views.toLocaleString()}</span>
                  </div>
                </div>
                <CardTitle className="line-clamp-2 group-hover:text-primary transition-colors">
                  {post.title}
                </CardTitle>
              </CardHeader>
              
              <CardContent className="pt-0">
                <p className="text-muted-foreground mb-4 line-clamp-3">
                  {post.excerpt}
                </p>
                
                <div className="flex items-center justify-between mb-4">
                  <span className="text-sm font-medium text-primary">{post.price}</span>
                  {post.affiliateLink && (
                    <Badge variant="outline" className="text-xs">
                      Commission Available
                    </Badge>
                  )}
                </div>
                
                <Button className="w-full group-hover:bg-primary/90">
                  Read Full Review
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Button variant="outline" size="lg">
            View All Reviews
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  )
}