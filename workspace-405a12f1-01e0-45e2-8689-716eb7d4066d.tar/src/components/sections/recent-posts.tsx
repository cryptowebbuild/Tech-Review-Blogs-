import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Star, Clock, Eye, ArrowRight, Heart, MessageCircle, Share2 } from 'lucide-react'

const recentPosts = [
  {
    id: 1,
    title: "Notion vs Obsidian: Which Note-Taking App is Right for You?",
    excerpt: "In-depth comparison of two powerful note-taking applications with different approaches to knowledge management.",
    author: "Sarah Johnson",
    authorAvatar: "SJ",
    category: "Productivity",
    image: "/api/placeholder/300/200",
    rating: 4.5,
    readTime: 10,
    views: 3420,
    publishedAt: "2 hours ago",
    likes: 145,
    comments: 23
  },
  {
    id: 2,
    title: "Canva Pro Review: Is It Worth the Upgrade in 2024?",
    excerpt: "Complete analysis of Canva Pro features, pricing, and whether it's worth upgrading from the free version.",
    author: "Mike Chen",
    authorAvatar: "MC",
    category: "Design Tools",
    image: "/api/placeholder/300/200",
    rating: 4.7,
    readTime: 8,
    views: 2150,
    publishedAt: "5 hours ago",
    likes: 89,
    comments: 15
  },
  {
    id: 3,
    title: "Webflow vs Framer: Best Website Builder for Designers",
    excerpt: "Comprehensive comparison of two popular website builders focused on design flexibility and ease of use.",
    author: "Emily Davis",
    authorAvatar: "ED",
    category: "Web Development",
    image: "/api/placeholder/300/200",
    rating: 4.6,
    readTime: 12,
    views: 1890,
    publishedAt: "1 day ago",
    likes: 67,
    comments: 8
  },
  {
    id: 4,
    title: "Adobe Creative Cloud All Apps Review: Value Analysis",
    excerpt: "Breaking down the value proposition of Adobe's complete creative suite and who should actually subscribe.",
    author: "Alex Rivera",
    authorAvatar: "AR",
    category: "Creative Software",
    image: "/api/placeholder/300/200",
    rating: 4.4,
    readTime: 15,
    views: 4560,
    publishedAt: "2 days ago",
    likes: 234,
    comments: 41
  }
]

export function RecentPosts() {
  return (
    <section className="py-16 lg:py-24">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
            Latest Reviews
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-[700px] mx-auto">
            Fresh insights and reviews published by our expert team
          </p>
        </div>
        
        <div className="grid gap-6 md:grid-cols-2">
          {recentPosts.map((post) => (
            <Card key={post.id} className="group hover:shadow-lg transition-all duration-300">
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/3">
                  <div className="aspect-video md:aspect-square bg-muted">
                    <img 
                      src={post.image} 
                      alt={post.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
                
                <div className="md:w-2/3 p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge variant="secondary" className="text-xs">
                      {post.category}
                    </Badge>
                    <span className="text-xs text-muted-foreground">{post.publishedAt}</span>
                  </div>
                  
                  <CardTitle className="text-lg mb-2 line-clamp-2 group-hover:text-primary transition-colors">
                    {post.title}
                  </CardTitle>
                  
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                    {post.excerpt}
                  </p>
                  
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="font-medium text-foreground">{post.rating}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>{post.readTime} min</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Eye className="h-4 w-4" />
                      <span>{post.views.toLocaleString()}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="text-xs">{post.authorAvatar}</AvatarFallback>
                      </Avatar>
                      <span className="text-sm font-medium">{post.author}</span>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Heart className="h-4 w-4" />
                        <span>{post.likes}</span>
                      </div>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <MessageCircle className="h-4 w-4" />
                        <span>{post.comments}</span>
                      </div>
                      <Button variant="ghost" size="sm" className="p-0 h-auto">
                        <Share2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Button variant="outline" size="lg">
            Load More Articles
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  )
}