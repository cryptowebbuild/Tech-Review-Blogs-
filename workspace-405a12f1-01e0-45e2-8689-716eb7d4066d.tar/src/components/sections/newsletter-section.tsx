import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Mail, Gift, CheckCircle } from 'lucide-react'

export function NewsletterSection() {
  return (
    <section className="py-16 lg:py-24 bg-primary text-primary-foreground">
      <div className="container px-4 md:px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-8">
            <Badge variant="secondary" className="mb-4">
              <Mail className="mr-2 h-4 w-4" />
              Join 10,000+ Subscribers
            </Badge>
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-4">
              Get Exclusive Reviews & Deals
            </h2>
            <p className="text-lg opacity-90 max-w-[600px] mx-auto">
              Subscribe to our newsletter and receive weekly product reviews, exclusive discounts, 
              and early access to new content.
            </p>
          </div>
          
          <div className="grid gap-6 md:grid-cols-3 mb-8">
            <Card className="bg-background/10 border-background/20">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-background/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Gift className="h-6 w-6" />
                </div>
                <h3 className="font-semibold mb-2">Exclusive Deals</h3>
                <p className="text-sm opacity-80">
                  Special discounts and affiliate offers not available anywhere else
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-background/10 border-background/20">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-background/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="h-6 w-6" />
                </div>
                <h3 className="font-semibold mb-2">Verified Reviews</h3>
                <p className="text-sm opacity-80">
                  Honest, tested reviews you can trust for your purchasing decisions
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-background/10 border-background/20">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-background/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Mail className="h-6 w-6" />
                </div>
                <h3 className="font-semibold mb-2">Weekly Digest</h3>
                <p className="text-sm opacity-80">
                  Curated content delivered straight to your inbox every Tuesday
                </p>
              </CardContent>
            </Card>
          </div>
          
          <div className="max-w-md mx-auto">
            <div className="flex flex-col sm:flex-row gap-2">
              <Input
                type="email"
                placeholder="Enter your email"
                className="bg-background/20 border-background/30 placeholder:text-muted-foreground text-foreground"
              />
              <Button variant="secondary" size="lg" className="flex-1 sm:flex-none">
                Subscribe Now
              </Button>
            </div>
            <p className="text-xs opacity-70 mt-3">
              No spam. Unsubscribe anytime. We respect your privacy.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}