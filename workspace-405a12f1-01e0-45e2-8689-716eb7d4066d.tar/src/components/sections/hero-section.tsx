import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ArrowRight, Star, TrendingUp } from 'lucide-react'

export function HeroSection() {
  return (
    <section className="relative bg-gradient-to-br from-primary/10 via-background to-secondary/10 py-20 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
          <div className="flex flex-col justify-center space-y-8">
            <div className="space-y-4">
              <Badge variant="secondary" className="w-fit">
                <TrendingUp className="mr-2 h-4 w-4" />
                Trusted by 50,000+ Readers
              </Badge>
              <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl">
                Digital Product Reviews
                <span className="block text-primary">That Actually Help</span>
              </h1>
              <p className="text-lg text-muted-foreground sm:text-xl md:text-2xl">
                Honest, in-depth reviews of digital products, software, and online courses. 
                Make informed decisions with our expert analysis and community insights.
              </p>
            </div>
            
            <div className="flex flex-col gap-4 sm:flex-row">
              <Button size="lg" className="text-lg px-8">
                Browse Reviews
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button variant="outline" size="lg" className="text-lg px-8">
                Join Community
              </Button>
            </div>

            <div className="flex items-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <span className="ml-2 font-medium text-foreground">4.9/5 Rating</span>
              </div>
              <div className="h-4 w-px bg-border" />
              <span>500+ Reviews Published</span>
            </div>
          </div>
          
          <div className="flex items-center justify-center">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-secondary/20 rounded-2xl blur-xl"></div>
              <div className="relative bg-background border rounded-2xl p-6 shadow-xl">
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                      <Star className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Featured Review</h3>
                      <p className="text-sm text-muted-foreground">Best AI Tools 2024</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-2 bg-muted rounded-full w-full"></div>
                    <div className="h-2 bg-muted rounded-full w-4/5"></div>
                    <div className="h-2 bg-muted rounded-full w-3/5"></div>
                  </div>
                  <Button variant="outline" className="w-full">
                    Read Full Review
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}