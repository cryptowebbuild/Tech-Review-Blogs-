import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { ArrowRight, TrendingUp, Package, GraduationCap, Palette, Code, Camera, Music, Video } from 'lucide-react'

const categories = [
  {
    id: 1,
    name: "AI Tools",
    description: "Artificial intelligence software and tools",
    icon: TrendingUp,
    postCount: 45,
    color: "bg-blue-500",
    trending: true
  },
  {
    id: 2,
    name: "Digital Products",
    description: "Downloadable products and resources",
    icon: Package,
    postCount: 32,
    color: "bg-green-500",
    trending: false
  },
  {
    id: 3,
    name: "Online Courses",
    description: "E-learning platforms and courses",
    icon: GraduationCap,
    postCount: 28,
    color: "bg-purple-500",
    trending: true
  },
  {
    id: 4,
    name: "Design Software",
    description: "Creative and design tools",
    icon: Palette,
    postCount: 36,
    color: "bg-pink-500",
    trending: false
  },
  {
    id: 5,
    name: "Development Tools",
    description: "Programming and development software",
    icon: Code,
    postCount: 41,
    color: "bg-orange-500",
    trending: true
  },
  {
    id: 6,
    name: "Photography",
    description: "Photo editing and management tools",
    icon: Camera,
    postCount: 24,
    color: "bg-cyan-500",
    trending: false
  },
  {
    id: 7,
    name: "Audio & Music",
    description: "Music production and audio software",
    icon: Music,
    postCount: 19,
    color: "bg-red-500",
    trending: false
  },
  {
    id: 8,
    name: "Video Editing",
    description: "Video production and editing tools",
    icon: Video,
    postCount: 27,
    color: "bg-indigo-500",
    trending: true
  }
]

export function CategoryGrid() {
  return (
    <section className="py-16 lg:py-24 bg-muted/30">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
            Browse Categories
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-[700px] mx-auto">
            Explore our comprehensive reviews organized by category
          </p>
        </div>
        
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {categories.map((category) => {
            const IconComponent = category.icon
            return (
              <Card key={category.id} className="group hover:shadow-lg transition-all duration-300 cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-lg ${category.color} bg-opacity-10`}>
                      <IconComponent className={`h-6 w-6 ${category.color.replace('bg-', 'text-')}`} />
                    </div>
                    {category.trending && (
                      <Badge variant="secondary" className="text-xs">
                        Trending
                      </Badge>
                    )}
                  </div>
                  
                  <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                    {category.name}
                  </h3>
                  
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                    {category.description}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                      {category.postCount} reviews
                    </span>
                    <Button variant="ghost" size="sm" className="p-0 h-auto">
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
        
        <div className="text-center mt-12">
          <Button size="lg">
            View All Categories
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  )
}