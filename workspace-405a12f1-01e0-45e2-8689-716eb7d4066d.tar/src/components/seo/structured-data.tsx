'use client'

import { useEffect } from 'react'

interface StructuredDataProps {
  data: Record<string, any>
}

export function StructuredData({ data }: StructuredDataProps) {
  useEffect(() => {
    // Remove existing structured data script if any
    const existingScript = document.querySelector('script[data-structured-data]')
    if (existingScript) {
      existingScript.remove()
    }

    // Create and add new structured data script
    const script = document.createElement('script')
    script.type = 'application/ld+json'
    script.setAttribute('data-structured-data', 'true')
    script.textContent = JSON.stringify(data)
    document.head.appendChild(script)

    return () => {
      // Cleanup on unmount
      const scriptToRemove = document.querySelector('script[data-structured-data]')
      if (scriptToRemove) {
        scriptToRemove.remove()
      }
    }
  }, [data])

  return null
}