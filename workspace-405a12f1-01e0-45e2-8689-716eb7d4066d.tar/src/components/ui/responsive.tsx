import { cn } from "@/lib/utils"

interface ResponsiveContainerProps {
  children: React.ReactNode
  className?: string
}

export function ResponsiveContainer({ children, className }: ResponsiveContainerProps) {
  return (
    <div className={cn(
      "container mx-auto px-4 sm:px-6 lg:px-8",
      className
    )}>
      {children}
    </div>
  )
}

interface ResponsiveGridProps {
  children: React.ReactNode
  className?: string
  cols?: {
    sm?: number
    md?: number
    lg?: number
    xl?: number
  }
  gap?: string
}

export function ResponsiveGrid({ 
  children, 
  className, 
  cols = { sm: 1, md: 2, lg: 3, xl: 4 },
  gap = "gap-4"
}: ResponsiveGridProps) {
  const gridClasses = Object.entries(cols)
    .map(([breakpoint, col]) => `${breakpoint === 'sm' ? 'grid-cols' : `${breakpoint}:grid-cols`}-${col}`)
    .join(' ')

  return (
    <div className={cn(
      `grid ${gridClasses} ${gap}`,
      className
    )}>
      {children}
    </div>
  )
}

interface ResponsiveTextProps {
  children: React.ReactNode
  className?: string
  size?: {
    base?: string
    sm?: string
    md?: string
    lg?: string
    xl?: string
  }
}

export function ResponsiveText({ 
  children, 
  className, 
  size = { base: 'text-base', sm: 'text-lg', md: 'text-xl', lg: 'text-2xl' }
}: ResponsiveTextProps) {
  const textClasses = Object.entries(size)
    .map(([breakpoint, textSize]) => breakpoint === 'base' ? textSize : `${breakpoint}:${textSize}`)
    .join(' ')

  return (
    <span className={cn(textClasses, className)}>
      {children}
    </span>
  )
}