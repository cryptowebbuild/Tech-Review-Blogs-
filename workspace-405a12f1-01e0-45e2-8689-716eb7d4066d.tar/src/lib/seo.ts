import { Metadata } from 'next'

interface SEOProps {
  title?: string
  description?: string
  keywords?: string[]
  image?: string
  url?: string
  type?: 'website' | 'article'
  publishedTime?: string
  modifiedTime?: string
  author?: string
  category?: string
  tags?: string[]
}

export function generateSEO(props: SEOProps): Metadata {
  const {
    title = 'TechReview Pro - Digital Product Reviews & Affiliate Marketing',
    description = 'Honest, in-depth reviews of digital products, software, and online courses. Make informed decisions with our expert analysis and community insights.',
    keywords = ['digital product reviews', 'affiliate marketing', 'software reviews', 'online courses', 'tech reviews', 'product comparisons'],
    image = '/api/og-image',
    url = 'https://techreviewpro.com',
    type = 'website',
    publishedTime,
    modifiedTime,
    author = 'TechReview Pro Team',
    category,
    tags
  } = props

  return {
    title,
    description,
    keywords: keywords.join(', '),
    authors: [{ name: author }],
    openGraph: {
      title,
      description,
      url,
      siteName: 'TechReview Pro',
      type,
      images: [
        {
          url: image,
          width: 1200,
          height: 630,
          alt: title,
        },
      ],
      publishedTime,
      modifiedTime,
      authors: [author],
      section: category,
      tags,
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
      images: [image],
      creator: '@techreviewpro',
      site: '@techreviewpro',
    },
    alternates: {
      canonical: url,
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        'max-video-preview': -1,
        'max-image-preview': 'large',
        'max-snippet': -1,
      },
    },
  }
}

export function generateStructuredData(props: SEOProps & { type: 'website' | 'article' | 'blog' | 'product' }) {
  const {
    title,
    description,
    url,
    image,
    type,
    publishedTime,
    modifiedTime,
    author,
    category,
    tags
  } = props

  const baseData = {
    '@context': 'https://schema.org',
    '@type': type === 'product' ? 'Product' : type === 'article' || type === 'blog' ? 'Article' : 'WebSite',
    name: title,
    description,
    url,
    image,
    author: {
      '@type': 'Person',
      name: author,
    },
    publisher: {
      '@type': 'Organization',
      name: 'TechReview Pro',
      logo: {
        '@type': 'ImageObject',
        url: '/logo.png',
      },
    },
  }

  if (type === 'article' || type === 'blog') {
    return {
      ...baseData,
      headline: title,
      datePublished: publishedTime,
      dateModified: modifiedTime,
      mainEntityOfPage: {
        '@type': 'WebPage',
        '@id': url,
      },
      articleSection: category,
      keywords: tags?.join(', '),
    }
  }

  if (type === 'product') {
    return {
      ...baseData,
      brand: {
        '@type': 'Brand',
        name: 'TechReview Pro',
      },
      review: {
        '@type': 'Review',
        reviewRating: {
          '@type': 'Rating',
          ratingValue: '4.5',
          bestRating: '5',
        },
        author: {
          '@type': 'Person',
          name: author,
        },
      },
    }
  }

  return baseData
}

export function generateBreadcrumbSchema(breadcrumbs: Array<{ name: string; url: string }>) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: breadcrumbs.map((breadcrumb, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: breadcrumb.name,
      item: breadcrumb.url,
    })),
  }
}

export function generateFAQSchema(faqs: Array<{ question: string; answer: string }>) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map(faq => ({
      '@type': 'Question',
      name: faq.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.answer,
      },
    })),
  }
}